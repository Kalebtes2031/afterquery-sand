# Horn Trade corridor desk — shipment review is unreliable

I'm on the East Africa produce corridor desk this week. Horn Trade Review is supposed to let me filter the queue, inspect a record, and approve or reject pending loads before the next border handoff. Right now several flows disagree with each other and the review panel layout makes it hard to read notes before signing off.

**Filtering.** Choosing "Pending" in the status dropdown does not leave me with only pending loads — I see approved and rejected rows mixed in instead. The country filter only seems to care about where a shipment starts; a load destined for Kenya (but originating elsewhere) never shows up when I filter for Kenya. Typing a commodity name like "sesame" into search and pressing Enter does not find HT-118 even though that row is in the dataset.

**Summary totals.** The corridor-weight stat at the top under-counts total kilograms. It looks like rejected shipments are being left out of the weight roll-up even though they still moved through the corridor. All six records together should weigh **5,590 kg** (pending, approved, and rejected included).

**Rejections.** I can reject a shipment with a blank reason and the API accepts it — that should not happen. Conversely, when I enter a proper rejection reason through the UI prompt, the request fails even though I typed text. Empty rejections must be refused and stay pending; a non-empty reason must persist on the record.

**Status display.** Every row badge in the queue reads "pending" regardless of actual state — HT-107 still shows pending even though it is approved, and HT-118 shows pending instead of rejected. The detail header badge has the same problem, so the queue and review panel disagree even though the "Current state" field inside the meta grid shows the right word.

**After decisions.** When I approve a pending shipment, the list badge should flip to approved immediately without a manual refresh. Already-decided shipments should keep their approve/reject buttons disabled.

**Layout.** The decision buttons float up over the reviewer note area so part of the note is hidden behind the controls. Notes and actions need to stay fully visible with clear separation — nothing overlapping or clipped off.

Current broken state:

<img src="/app/problem_assets/broken.png" alt="Horn Trade Review with overlapping review controls" width="900" />

Expected fixed state (same viewport, same All statuses view):

<img src="/app/problem_assets/target.png" alt="Horn Trade Review with readable notes and separated controls" width="900" />
