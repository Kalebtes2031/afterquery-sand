const http = require('http');
const { passes } = require('./lib/seed');
const { buildRegisterSummary } = require('./lib/summary');

const PORT = Number(process.env.PORT || 5000);

function send(res, status, body, type = 'application/json') {
  res.writeHead(status, { 'Content-Type': type, 'Access-Control-Allow-Origin': '*' });
  res.end(type === 'application/json' ? JSON.stringify(body) : body);
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/health') return send(res, 200, { ok: true });
  if (req.url === '/api/passes') return send(res, 200, { passes });
  if (req.url === '/api/register-summary') return send(res, 200, buildRegisterSummary(passes));
  if (req.url === '/') return send(res, 200, 'Nile Heritage Pass API', 'text/plain');
  return send(res, 404, { error: 'not found' });
});

server.listen(PORT, '0.0.0.0', () => console.log(`backend on ${PORT}`));
