async function bootRegister() {
  const [passesPayload, summaryPayload] = await Promise.all([
    fetch('http://localhost:5000/api/passes').then(r => r.json()),
    fetch('http://localhost:5000/api/register-summary').then(r => r.json())
  ]);

  RegisterView.paintSummary(summaryPayload);
  RegisterView.paintRows(passesPayload.passes);
}

bootRegister().catch(console.error);
