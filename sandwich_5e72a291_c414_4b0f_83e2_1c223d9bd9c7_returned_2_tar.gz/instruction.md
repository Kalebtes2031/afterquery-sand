# AfriGrid control room is giving operators inconsistent live-shift data

I’m monitoring solar microgrids across Africa. The control room currently has six linked problems: the community tariff applies the solar feed-in credit before the 50 kWh lifeline subsidy, the critical clinic override does not return the updated protected circuit to the UI, a BESS DISCHARGE command reports OFFLINE_TRIPPED and puts the hottest rack last, assigning three field engineers returns broken roster data, African currency totals can appear in scientific notation, and the control-room layout has overflowing filters/overlapping cards, an unreadable warning badge, and an emergency drawer that covers the navigation.

Please fix those six behaviors without breaking the existing health endpoint or the five-hub microgrid catalog.

The broken webpage looks as follows with overlapping cards, uncompleted filter controls, unreasonable contrast, and the inconsistent operational data:

<img src="/app/problem_assets/broken.png" alt="current broken AfriGrid control room" width="900" />

The expected webpage should show distinct cards, usable filters, a readable warning state, and a contained emergency control surface:

<img src="/app/problem_assets/target.png" alt="expected AfriGrid control room" width="900" />
