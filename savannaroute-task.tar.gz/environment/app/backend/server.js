const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Initial In-Memory State for African Reserves and Expeditions
let expeditions = [
  {
    id: 'EXP-101',
    reserve: 'Serengeti National Park',
    country: 'Tanzania',
    title: 'Great Migration River Crossing Odyssey',
    durationDays: 7,
    teamSize: 4,
    leadGuide: 'Juma Mwangi',
    status: 'ACTIVE',
    permitType: 'Wildlife Game Drive',
    permitStatus: 'ISSUED',
    startDate: '2026-09-15',
    baseRatePerDay: 450,
    peakSeason: true,
    discountPct: 10,
    assignedRangers: [
      { id: 'R-1', name: 'Kato Mugisha', rank: 'Senior Scout' },
      { id: 'R-2', name: 'Amina Kimaro', rank: 'Wildlife Ranger' }
    ]
  },
  {
    id: 'EXP-102',
    reserve: 'Bwindi Impenetrable National Park',
    country: 'Uganda',
    title: 'Silverback Gorilla Habituation Trek',
    durationDays: 4,
    teamSize: 6,
    leadGuide: 'Grace Nabatanzi',
    status: 'ACTIVE',
    permitType: 'Gorilla Tracking Permit',
    permitStatus: 'PENDING',
    startDate: '2026-09-20',
    baseRatePerDay: 750,
    peakSeason: true,
    discountPct: 5,
    assignedRangers: [
      { id: 'R-3', name: 'Emmanuel Kiprono', rank: 'Lead Tracker' }
    ]
  },
  {
    id: 'EXP-103',
    reserve: 'Maasai Mara Game Reserve',
    country: 'Kenya',
    title: 'Big Five & Predator Nocturnal Safari',
    durationDays: 5,
    teamSize: 3,
    leadGuide: 'Ole Kaelo',
    status: 'ACTIVE',
    permitType: 'Night Game Drive & Ranger Escort',
    permitStatus: 'ISSUED',
    startDate: '2026-09-18',
    baseRatePerDay: 520,
    peakSeason: false,
    discountPct: 0,
    assignedRangers: [
      { id: 'R-4', name: 'Samuel Ndung’u', rank: 'Patrol Officer' },
      { id: 'R-5', name: 'Zahara Omondi', rank: 'Conservation Warden' }
    ]
  },
  {
    id: 'EXP-104',
    reserve: 'Okavango Delta',
    country: 'Botswana',
    title: 'Mokoro Waterways & Wetland Wilderness',
    durationDays: 6,
    teamSize: 2,
    leadGuide: 'Tebogo Kgosi',
    status: 'ACTIVE',
    permitType: 'Wetland Navigation Permit',
    permitStatus: 'ISSUED',
    startDate: '2026-10-01',
    baseRatePerDay: 680,
    peakSeason: true,
    discountPct: 15,
    assignedRangers: [
      { id: 'R-6', name: 'Thabo Motsumi', rank: 'Aquatic Guide' }
    ]
  }
];

let fleet = [
  {
    id: 'VEH-401',
    name: 'Land Cruiser 4x4 - Mara 01',
    capacity: 6,
    status: 'STANDBY',
    currentRoute: 'Mara Triangle Traverse'
  },
  {
    id: 'VEH-402',
    name: 'Land Cruiser Extended - Serengeti 04',
    capacity: 8,
    status: 'DISPATCHED',
    currentRoute: 'Seronera to Mara River Corridor'
  },
  {
    id: 'VEH-403',
    name: 'Toyota Hilux Support - Bwindi 02',
    capacity: 4,
    status: 'STANDBY',
    currentRoute: 'Ruhija High Altitude Pass'
  }
];

let routes = [
  {
    id: 'RT-1',
    name: 'Seronera to Mara River Corridor',
    reserve: 'Serengeti National Park',
    distanceKm: 240,
    waypoints: [
      { order: 1, name: 'Seronera Airstrip Hub', estHours: 0 },
      { order: 2, name: 'Retima Hippo Pool Checkpoint', estHours: 2.5 },
      { order: 3, name: 'Lobo Kopjes Ranger Post', estHours: 5.0 },
      { order: 4, name: 'Kogatende River Crossing Point 4', estHours: 8.0 }
    ]
  },
  {
    id: 'RT-2',
    name: 'Ruhija High Altitude Pass',
    reserve: 'Bwindi Impenetrable National Park',
    distanceKm: 85,
    waypoints: [
      { order: 1, name: 'Kabale Transit Station', estHours: 0 },
      { order: 2, name: 'Ruhija Sector Gate', estHours: 2.0 },
      { order: 3, name: 'Mubwindi Swamp Ridge', estHours: 4.5 }
    ]
  }
];

let rangersPool = [
  { id: 'R-1', name: 'Kato Mugisha', rank: 'Senior Scout', specialty: 'Savanna Tracking' },
  { id: 'R-2', name: 'Amina Kimaro', rank: 'Wildlife Ranger', specialty: 'Anti-Poaching' },
  { id: 'R-3', name: 'Emmanuel Kiprono', rank: 'Lead Tracker', specialty: 'Primate Habituation' },
  { id: 'R-4', name: 'Samuel Ndung’u', rank: 'Patrol Officer', specialty: 'Nocturnal Escort' },
  { id: 'R-5', name: 'Zahara Omondi', rank: 'Conservation Warden', specialty: 'Wildlife Ecology' },
  { id: 'R-6', name: 'Thabo Motsumi', rank: 'Aquatic Guide', specialty: 'Delta Navigation' },
  { id: 'R-7', name: 'Baraka Mollel', rank: 'Maasai Field Ranger', specialty: 'Bush Survival' }
];

// Health Check Endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'ok',
    service: 'savannaroute-core-api',
    timestamp: new Date().toISOString()
  });
});

// Stats Endpoint
app.get('/api/stats', (req, res) => {
  const activeSafaris = expeditions.filter(e => e.status === 'ACTIVE').length;
  const issuedPermits = expeditions.filter(e => e.permitStatus === 'ISSUED').length;
  const dispatchedVehicles = fleet.filter(f => f.status === 'DISPATCHED').length;
  res.json({
    activeSafaris,
    issuedPermits,
    dispatchedVehicles,
    totalFleet: fleet.length
  });
});

// Expeditions Endpoints
app.get('/api/expeditions', (req, res) => {
  res.json(expeditions);
});

app.get('/api/expeditions/:id', (req, res) => {
  const exp = expeditions.find(e => e.id === req.params.id);
  if (!exp) {
    return res.status(404).json({ error: 'Expedition not found' });
  }
  res.json(exp);
});

// D2 Base Bug: Permit Quota & Response Structure
// In broken base: Doesn't check date reservation quotas properly, and returns unwrapped permitStatus
app.post('/api/expeditions/:id/permits', (req, res) => {
  const exp = expeditions.find(e => e.id === req.params.id);
  if (!exp) {
    return res.status(404).json({ error: 'Expedition not found' });
  }

  const { teamSize, date } = req.body;
  const requestedSize = teamSize || exp.teamSize;

  // BROKEN LOGIC for D2:
  // Fails to check existing booked permits on that date against the daily limit (8 permits max).
  // Also returns unwrapped response instead of updated expedition object.
  if (requestedSize > 8) {
    return res.status(400).json({ error: 'Exceeds single group max permit limit' });
  }

  exp.permitStatus = 'ISSUED';
  exp.permitDate = date || exp.startDate;

  // Broken response contract: returns permitStatus directly rather than updated expedition
  res.json({
    success: true,
    permitStatus: 'ISSUED',
    message: 'Gorilla tracking permit allocated'
  });
});

// Dispatch Endpoints
app.get('/api/dispatch/fleet', (req, res) => {
  res.json(fleet);
});

app.get('/api/dispatch/routes', (req, res) => {
  res.json(routes);
});

// D3 Base Bug: Vehicle status inversion & Route waypoints sorted DESC
app.post('/api/dispatch/assign', (req, res) => {
  const { vehicleId, routeId, dispatchStatus } = req.body;
  const vehicle = fleet.find(v => v.id === vehicleId);
  const route = routes.find(r => r.id === routeId);

  if (!vehicle || !route) {
    return res.status(404).json({ error: 'Vehicle or Route not found' });
  }

  const isDispatching = dispatchStatus === 'DISPATCH';

  // BROKEN LOGIC for D3:
  // Inverted status: when dispatching, sets status to DECOMMISSIONED instead of DISPATCHED!
  vehicle.status = isDispatching ? 'DECOMMISSIONED' : 'DISPATCHED';
  vehicle.currentRoute = route.name;

  // Broken checkpoint ordering: sorts by name descending instead of sequence order ascending
  const waypoints = [...route.waypoints].sort((a, b) => b.name.localeCompare(a.name));

  res.json({
    success: true,
    vehicle,
    activeRoute: {
      id: route.id,
      name: route.name,
      waypoints
    }
  });
});

// Rangers Endpoints
app.get('/api/rangers', (req, res) => {
  res.json(rangersPool);
});

// D4 Base Bug: Ranger allocation type serialization mismatch
app.post('/api/rangers/assign', (req, res) => {
  const { expeditionId, rangerIds } = req.body;
  const exp = expeditions.find(e => e.id === expeditionId);
  if (!exp) {
    return res.status(404).json({ error: 'Expedition not found' });
  }

  if (!Array.isArray(rangerIds) || rangerIds.length === 0) {
    return res.status(400).json({ error: 'rangerIds array required' });
  }

  const selectedRangers = rangersPool.filter(r => rangerIds.includes(r.id));

  // BROKEN LOGIC for D4:
  // When assigning > 2 rangers, returns array of plain strings instead of ranger objects
  if (selectedRangers.length > 2) {
    exp.assignedRangers = selectedRangers.map(r => r.id);
  } else {
    exp.assignedRangers = selectedRangers;
  }

  res.json({
    success: true,
    expeditionId: exp.id,
    assignedRangers: exp.assignedRangers
  });
});

// D1 Base Bug: Pricing & Conservation Levy Calculation
app.post('/api/pricing/calculate', (req, res) => {
  const {
    baseRatePerDay = 450,
    durationDays = 5,
    teamSize = 2,
    peakSeason = false,
    discountPct = 0,
    rangersCount = 1,
    escortFeePerRanger = 120,
    conservationLevyPerGuest = 70
  } = req.body;

  const days = Number(durationDays) || 1;
  const guests = Number(teamSize) || 1;
  const baseRate = Number(baseRatePerDay) || 0;
  const discount = Number(discountPct) || 0;
  const rangers = Number(rangersCount) || 0;
  const escortFee = Number(escortFeePerRanger) || 0;
  const levyPerGuest = Number(conservationLevyPerGuest) || 0;

  const seasonalMultiplier = peakSeason ? 1.4 : 1.0;
  const totalLevy = levyPerGuest * guests * days;

  // BROKEN LOGIC for D1:
  // Subtracts levy BEFORE multiplying seasonal rate, applies double discount factor,
  // producing wrong or negative pricing breakdown.
  const subtotal = baseRate * days * guests;
  const discountedSubtotal = subtotal - (subtotal * discount); // double counts percentage if discount is e.g. 10
  const taxableBase = discountedSubtotal - totalLevy;
  const seasonalAdjusted = taxableBase * seasonalMultiplier;
  const totalCost = seasonalAdjusted + (escortFee * rangers);

  res.json({
    subtotal: Math.round(subtotal),
    discountApplied: Math.round(subtotal - discountedSubtotal),
    conservationLevy: totalLevy,
    seasonalMultiplier,
    rangerEscortCost: escortFee * rangers,
    totalCost: Math.round(totalCost)
  });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[SavannaRoute API] Server listening on port ${PORT}`);
});
