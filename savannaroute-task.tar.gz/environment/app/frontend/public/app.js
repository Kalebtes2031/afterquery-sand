// SavannaRoute Frontend Application Logic

const BACKEND_URL = window.BACKEND_URL !== undefined ? window.BACKEND_URL : '';

const INITIAL_EXPEDITIONS = [
  {
    id: 'EXP-101',
    reserve: 'Serengeti National Park',
    country: 'Tanzania',
    title: 'Great Migration River Crossing Odyssey',
    durationDays: 7,
    teamSize: 4,
    leadGuide: 'Juma Mwangi',
    status: 'ACTIVE',
    permitType: 'Wildlife Game Drive',
    permitStatus: 'ISSUED',
    startDate: '2026-09-15',
    baseRatePerDay: 450,
    peakSeason: true,
    discountPct: 10,
    assignedRangers: [
      { id: 'R-1', name: 'Kato Mugisha', rank: 'Senior Scout' },
      { id: 'R-2', name: 'Amina Kimaro', rank: 'Wildlife Ranger' }
    ]
  },
  {
    id: 'EXP-102',
    reserve: 'Bwindi Impenetrable National Park',
    country: 'Uganda',
    title: 'Silverback Gorilla Habituation Trek',
    durationDays: 4,
    teamSize: 6,
    leadGuide: 'Grace Nabatanzi',
    status: 'ACTIVE',
    permitType: 'Gorilla Tracking Permit',
    permitStatus: 'PENDING',
    startDate: '2026-09-20',
    baseRatePerDay: 750,
    peakSeason: true,
    discountPct: 5,
    assignedRangers: [
      { id: 'R-3', name: 'Emmanuel Kiprono', rank: 'Lead Tracker' }
    ]
  },
  {
    id: 'EXP-103',
    reserve: 'Maasai Mara Game Reserve',
    country: 'Kenya',
    title: 'Big Five & Predator Nocturnal Safari',
    durationDays: 5,
    teamSize: 3,
    leadGuide: 'Ole Kaelo',
    status: 'ACTIVE',
    permitType: 'Night Game Drive & Ranger Escort',
    permitStatus: 'ISSUED',
    startDate: '2026-09-18',
    baseRatePerDay: 520,
    peakSeason: false,
    discountPct: 0,
    assignedRangers: [
      { id: 'R-4', name: 'Samuel Ndung’u', rank: 'Patrol Officer' },
      { id: 'R-5', name: 'Zahara Omondi', rank: 'Conservation Warden' }
    ]
  },
  {
    id: 'EXP-104',
    reserve: 'Okavango Delta',
    country: 'Botswana',
    title: 'Mokoro Waterways & Wetland Wilderness',
    durationDays: 6,
    teamSize: 2,
    leadGuide: 'Tebogo Kgosi',
    status: 'ACTIVE',
    permitType: 'Wetland Navigation Permit',
    permitStatus: 'ISSUED',
    startDate: '2026-10-01',
    baseRatePerDay: 680,
    peakSeason: true,
    discountPct: 15,
    assignedRangers: [
      { id: 'R-6', name: 'Thabo Motsumi', rank: 'Aquatic Guide' }
    ]
  }
];

const INITIAL_FLEET = [
  {
    id: 'VEH-401',
    name: 'Land Cruiser 4x4 - Mara 01',
    capacity: 6,
    status: 'STANDBY',
    currentRoute: 'Mara Triangle Traverse'
  },
  {
    id: 'VEH-402',
    name: 'Land Cruiser Extended - Serengeti 04',
    capacity: 8,
    status: 'DISPATCHED',
    currentRoute: 'Seronera to Mara River Corridor'
  },
  {
    id: 'VEH-403',
    name: 'Toyota Hilux Support - Bwindi 02',
    capacity: 4,
    status: 'STANDBY',
    currentRoute: 'Ruhija High Altitude Pass'
  }
];

const INITIAL_ROUTES = [
  {
    id: 'RT-1',
    name: 'Seronera to Mara River Corridor',
    reserve: 'Serengeti National Park',
    distanceKm: 240,
    waypoints: [
      { order: 1, name: 'Seronera Airstrip Hub', estHours: 0 },
      { order: 2, name: 'Retima Hippo Pool Checkpoint', estHours: 2.5 },
      { order: 3, name: 'Lobo Kopjes Ranger Post', estHours: 5.0 },
      { order: 4, name: 'Kogatende River Crossing Point 4', estHours: 8.0 }
    ]
  },
  {
    id: 'RT-2',
    name: 'Ruhija High Altitude Pass',
    reserve: 'Bwindi Impenetrable National Park',
    distanceKm: 85,
    waypoints: [
      { order: 1, name: 'Kabale Transit Station', estHours: 0 },
      { order: 2, name: 'Ruhija Sector Gate', estHours: 2.0 },
      { order: 3, name: 'Mubwindi Swamp Ridge', estHours: 4.5 }
    ]
  }
];

const INITIAL_RANGERS = [
  { id: 'R-1', name: 'Kato Mugisha', rank: 'Senior Scout', specialty: 'Savanna Tracking' },
  { id: 'R-2', name: 'Amina Kimaro', rank: 'Wildlife Ranger', specialty: 'Anti-Poaching' },
  { id: 'R-3', name: 'Emmanuel Kiprono', rank: 'Lead Tracker', specialty: 'Primate Habituation' },
  { id: 'R-4', name: 'Samuel Ndung’u', rank: 'Patrol Officer', specialty: 'Nocturnal Escort' },
  { id: 'R-5', name: 'Zahara Omondi', rank: 'Conservation Warden', specialty: 'Wildlife Ecology' },
  { id: 'R-6', name: 'Thabo Motsumi', rank: 'Aquatic Guide', specialty: 'Delta Navigation' },
  { id: 'R-7', name: 'Baraka Mollel', rank: 'Maasai Field Ranger', specialty: 'Bush Survival' }
];

// State
let state = {
  expeditions: [...INITIAL_EXPEDITIONS],
  fleet: [...INITIAL_FLEET],
  routes: [...INITIAL_ROUTES],
  rangers: [...INITIAL_RANGERS],
  selectedExpedition: null,
  activeFilter: 'ALL',
  currency: 'USD',
  currencyRates: {
    USD: { symbol: '$', rate: 1.0, decimals: 0 },
    KES: { symbol: 'KSh ', rate: 130.0, decimals: 0 },
    TZS: { symbol: 'TSh ', rate: 2600.0, decimals: 0 },
    UGX: { symbol: 'USh ', rate: 3700.0, decimals: 0 }
  }
};

// D5 Base Bug: Currency formatting without locale separation
function formatMoney(amountInUSD) {
  const c = state.currencyRates[state.currency] || state.currencyRates.USD;
  const converted = amountInUSD * c.rate;
  if (converted >= 1000000) {
    return `${c.symbol}${converted.toExponential(2)}`;
  }
  return `${c.symbol}${converted.toFixed(c.decimals)}`;
}

// Initialize Application
document.addEventListener('DOMContentLoaded', () => {
  setupNavigation();
  setupCurrencySelector();
  setupFilterBar();
  setupPricingCalculator();
  setupDispatch();
  setupModalEvents();

  renderExpeditions();
  renderFleet();
  renderWaypoints(state.routes[0]);
  populateRangerChecklist();
  calculateAndRenderCost();

  fetchInitialData();
});

// Navigation Tabs
function setupNavigation() {
  const tabs = document.querySelectorAll('.tab-btn');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const targetTab = tab.getAttribute('data-tab');
      document.querySelectorAll('.tab-section').forEach(sec => sec.classList.remove('active'));
      const activeSection = document.getElementById(`section-${targetTab}`);
      if (activeSection) {
        activeSection.classList.add('active');
      }
    });
  });
}

// Currency Selector
function setupCurrencySelector() {
  const select = document.getElementById('currency-select');
  if (!select) return;
  select.addEventListener('change', (e) => {
    state.currency = e.target.value;
    renderExpeditions();
    calculateAndRenderCost();
  });
}

// Reserve Filters
function setupFilterBar() {
  const pills = document.querySelectorAll('.filter-pill');
  pills.forEach(pill => {
    pill.addEventListener('click', () => {
      pills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      state.activeFilter = pill.getAttribute('data-filter');
      renderExpeditions();
    });
  });
}

// Fetch Initial Data from Backend
async function fetchInitialData() {
  try {
    const [expRes, fleetRes, routesRes, rangersRes, statsRes] = await Promise.all([
      fetch(`${BACKEND_URL}/api/expeditions`).then(r => r.json()).catch(() => null),
      fetch(`${BACKEND_URL}/api/dispatch/fleet`).then(r => r.json()).catch(() => null),
      fetch(`${BACKEND_URL}/api/dispatch/routes`).then(r => r.json()).catch(() => null),
      fetch(`${BACKEND_URL}/api/rangers`).then(r => r.json()).catch(() => null),
      fetch(`${BACKEND_URL}/api/stats`).then(r => r.json()).catch(() => null)
    ]);

    if (expRes && Array.isArray(expRes)) state.expeditions = expRes;
    if (fleetRes && Array.isArray(fleetRes)) state.fleet = fleetRes;
    if (routesRes && Array.isArray(routesRes)) state.routes = routesRes;
    if (rangersRes && Array.isArray(rangersRes)) state.rangers = rangersRes;

    if (statsRes) updateStats(statsRes);
    renderExpeditions();
    renderFleet();
    if (state.routes.length > 0) renderWaypoints(state.routes[0]);
    populateRangerChecklist();
  } catch (err) {
    console.error('Failed to sync data with backend:', err);
  }
}

// Update KPI Stats
function updateStats(stats) {
  if (!stats) return;
  const elActive = document.getElementById('stat-active-safaris');
  const elPermits = document.getElementById('stat-issued-permits');
  const elFleet = document.getElementById('stat-fleet-readiness');

  if (elActive && stats.activeSafaris !== undefined) elActive.textContent = stats.activeSafaris;
  if (elPermits && stats.issuedPermits !== undefined) elPermits.textContent = stats.issuedPermits;
  if (elFleet && stats.dispatchedVehicles !== undefined && stats.totalFleet !== undefined) {
    elFleet.textContent = `${stats.dispatchedVehicles}/${stats.totalFleet} Dispatched`;
  }
}

// Render Expeditions
function renderExpeditions() {
  const container = document.getElementById('expedition-cards-container');
  if (!container) return;

  const filtered = state.activeFilter === 'ALL'
    ? state.expeditions
    : state.expeditions.filter(e => e.reserve === state.activeFilter);

  container.innerHTML = filtered.map(exp => {
    const permitBadgeClass = exp.permitStatus === 'ISSUED' ? 'badge-issued' : 'badge-pending';
    const peakBadge = exp.peakSeason ? `<span class="badge badge-peak">Peak Season (1.4x)</span>` : '';
    
    const rangerChips = (exp.assignedRangers || []).map(r => {
      const name = typeof r === 'object' ? r.name : `Ranger #${r}`;
      return `<span class="ranger-chip">🛡️ ${name}</span>`;
    }).join('');

    const estCost = exp.baseRatePerDay * exp.durationDays * exp.teamSize;

    return `
      <div class="expedition-card" data-exp-id="${exp.id}">
        <div class="card-top">
          <div class="card-reserve-tag">${exp.country} &bull; ${exp.reserve}</div>
          <h3 class="card-title">${exp.title}</h3>
          <div class="card-meta">
            <span>⏳ ${exp.durationDays} Days</span>
            <span>👥 ${exp.teamSize} Explorers</span>
            <span>🧭 Guide: ${exp.leadGuide}</span>
            <span>📅 Starts: ${exp.startDate}</span>
          </div>
          <div class="card-badges">
            <span class="badge ${permitBadgeClass}" id="permit-badge-${exp.id}">${exp.permitStatus}</span>
            ${peakBadge}
          </div>
          <div class="ranger-chips">
            ${rangerChips}
          </div>
        </div>
        <div class="card-bottom">
          <div style="margin-bottom: 0.75rem; font-size: 0.9rem; font-weight: 700; color: #fbbf24;">
            Est. Base: ${formatMoney(estCost)}
          </div>
          <div class="card-actions">
            <button class="btn btn-outline btn-manage" onclick="openExpeditionModal('${exp.id}')">Manage Logistics</button>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Render Fleet
function renderFleet() {
  const container = document.getElementById('fleet-vehicles-list');
  if (!container) return;

  container.innerHTML = state.fleet.map(v => {
    const statusClass = v.status === 'DISPATCHED' ? 'badge-dispatched' : (v.status === 'STANDBY' ? 'badge-standby' : 'badge-maintenance');
    return `
      <div class="fleet-card">
        <div class="fleet-info">
          <h4>${v.name}</h4>
          <p>Capacity: ${v.capacity} Passengers &bull; Active: ${v.currentRoute}</p>
        </div>
        <div>
          <span class="badge ${statusClass}" id="fleet-status-${v.id}">${v.status}</span>
        </div>
      </div>
    `;
  }).join('');
}

// Render Waypoints Timeline
function renderWaypoints(route) {
  const container = document.getElementById('waypoints-timeline');
  const title = document.getElementById('active-route-name');
  if (!container || !route) return;

  if (title) title.textContent = route.name;

  container.innerHTML = (route.waypoints || []).map(wp => `
    <div class="waypoint-item">
      <div class="waypoint-name">${wp.order ? `${wp.order}. ` : ''}${wp.name}</div>
      <div class="waypoint-meta">Estimated Transit: +${wp.estHours} hrs from departure</div>
    </div>
  `).join('');
}

// Setup Fleet Dispatch Interaction
function setupDispatch() {
  const btn = document.getElementById('btn-dispatch-vehicle');
  const routeSelect = document.getElementById('dispatch-route-select');
  const vehicleSelect = document.getElementById('dispatch-vehicle-select');

  if (routeSelect) {
    routeSelect.addEventListener('change', () => {
      const route = state.routes.find(r => r.id === routeSelect.value);
      if (route) renderWaypoints(route);
    });
  }

  if (btn) {
    btn.addEventListener('click', async () => {
      const vehicleId = vehicleSelect.value;
      const routeId = routeSelect.value;

      try {
        const res = await fetch(`${BACKEND_URL}/api/dispatch/assign`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            vehicleId,
            routeId,
            dispatchStatus: 'DISPATCH'
          })
        }).then(r => r.json());

        if (res.success && res.vehicle) {
          const idx = state.fleet.findIndex(f => f.id === res.vehicle.id);
          if (idx !== -1) {
            state.fleet[idx] = res.vehicle;
          }
          renderFleet();
          if (res.activeRoute) {
            renderWaypoints(res.activeRoute);
          }
        }
      } catch (err) {
        console.error('Dispatch failed:', err);
      }
    });
  }
}

// Setup Pricing Calculator
function setupPricingCalculator() {
  const btn = document.getElementById('btn-calculate-cost');
  if (btn) {
    btn.addEventListener('click', calculateAndRenderCost);
  }
}

async function calculateAndRenderCost() {
  const reserveSelect = document.getElementById('calc-reserve');
  const daysInput = document.getElementById('calc-days');
  const guestsInput = document.getElementById('calc-guests');
  const rangersInput = document.getElementById('calc-rangers');
  const peakInput = document.getElementById('calc-peak-season');
  const discountInput = document.getElementById('calc-discount');

  if (!reserveSelect) return;

  const baseRatePerDay = Number(reserveSelect.value);
  const conservationLevyPerGuest = Number(reserveSelect.selectedOptions[0]?.dataset.levy || 70);
  const durationDays = Number(daysInput?.value || 5);
  const teamSize = Number(guestsInput?.value || 4);
  const rangersCount = Number(rangersInput?.value || 2);
  const peakSeason = Boolean(peakInput?.checked);
  const discountPct = Number(discountInput?.value || 10);

  try {
    const res = await fetch(`${BACKEND_URL}/api/pricing/calculate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        baseRatePerDay,
        durationDays,
        teamSize,
        peakSeason,
        discountPct,
        rangersCount,
        escortFeePerRanger: 120,
        conservationLevyPerGuest
      })
    }).then(r => r.json());

    document.getElementById('val-base-subtotal').textContent = formatMoney(res.subtotal);
    document.getElementById('val-discount').textContent = `-${formatMoney(res.discountApplied)}`;
    document.getElementById('val-seasonal').textContent = peakSeason ? '1.4x Applied' : 'Standard Rate';
    document.getElementById('val-levy').textContent = formatMoney(res.conservationLevy);
    document.getElementById('val-rangers').textContent = formatMoney(res.rangerEscortCost);
    document.getElementById('val-total-cost').textContent = formatMoney(res.totalCost);
    document.getElementById('val-currency-note').textContent = `Calculated in ${state.currency}`;
  } catch (err) {
    console.error('Pricing calculation failed:', err);
  }
}

// Modal & Logistics Handlers
function setupModalEvents() {
  const closeBtn = document.getElementById('btn-close-modal');
  const requestPermitBtn = document.getElementById('btn-request-permit');
  const saveRangersBtn = document.getElementById('btn-save-rangers');

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('expedition-modal').style.display = 'none';
    });
  }

  // D2 Base Bug in action: reads `res.data.permitStatus` instead of `res.data.expedition`
  if (requestPermitBtn) {
    requestPermitBtn.addEventListener('click', async () => {
      if (!state.selectedExpedition) return;
      const teamSize = Number(document.getElementById('permit-team-size').value);
      const msg = document.getElementById('permit-result-message');

      try {
        const res = await fetch(`${BACKEND_URL}/api/expeditions/${state.selectedExpedition.id}/permits`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ teamSize })
        }).then(r => r.json());

        if (res.success && res.permitStatus) {
          msg.textContent = '✓ Gorilla Permit Allocated & Verified!';
          msg.style.color = '#34d399';
          state.selectedExpedition.permitStatus = res.permitStatus;
          renderExpeditions();
        } else {
          msg.textContent = `✗ ${res.error || 'Permit request failed'}`;
          msg.style.color = '#ef4444';
        }
      } catch (err) {
        msg.textContent = '✗ Network request failed';
        msg.style.color = '#ef4444';
      }
    });
  }

  // D4 Base Bug in action: saving > 2 rangers
  if (saveRangersBtn) {
    saveRangersBtn.addEventListener('click', async () => {
      if (!state.selectedExpedition) return;
      const checkboxes = document.querySelectorAll('input[name="ranger-choice"]:checked');
      const rangerIds = Array.from(checkboxes).map(cb => cb.value);
      const msg = document.getElementById('ranger-result-message');

      try {
        const res = await fetch(`${BACKEND_URL}/api/rangers/assign`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            expeditionId: state.selectedExpedition.id,
            rangerIds
          })
        }).then(r => r.json());

        if (res.success) {
          msg.textContent = `✓ Assigned ${res.assignedRangers.length} rangers!`;
          msg.style.color = '#34d399';
          state.selectedExpedition.assignedRangers = res.assignedRangers;
          renderExpeditions();
        }
      } catch (err) {
        msg.textContent = '✗ Failed to assign rangers';
        msg.style.color = '#ef4444';
      }
    });
  }
}

function openExpeditionModal(expId) {
  const exp = state.expeditions.find(e => e.id === expId);
  if (!exp) return;
  state.selectedExpedition = exp;

  document.getElementById('modal-exp-id').textContent = exp.id;
  document.getElementById('modal-exp-title').textContent = `${exp.title} Logistics`;
  document.getElementById('modal-exp-reserve').textContent = `${exp.reserve} (${exp.country})`;
  document.getElementById('modal-exp-permit-type').textContent = exp.permitType;
  
  const statusEl = document.getElementById('modal-exp-permit-status');
  statusEl.textContent = exp.permitStatus;
  statusEl.className = `badge ${exp.permitStatus === 'ISSUED' ? 'badge-issued' : 'badge-pending'}`;

  document.getElementById('permit-result-message').textContent = '';
  document.getElementById('ranger-result-message').textContent = '';

  document.getElementById('expedition-modal').style.display = 'block';
}
window.openExpeditionModal = openExpeditionModal;

function populateRangerChecklist() {
  const list = document.getElementById('ranger-select-list');
  if (!list) return;

  list.innerHTML = state.rangers.map(r => `
    <label class="ranger-check-item">
      <input type="checkbox" name="ranger-choice" value="${r.id}" />
      <span>${r.name} (${r.specialty})</span>
    </label>
  `).join('');
}
