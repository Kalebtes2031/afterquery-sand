// ═══════════════════════════════════════════════════
// SCATTER PLOT
// ═══════════════════════════════════════════════════
import { flooringData, AXIS_META } from './materials.js';
import { state, textureCache, pushHistory, persistState } from './state.js';

const PADDING = { left: 12, right: 12, top: 12, bottom: 12 };

export const nodeEls = {};

const $scatter = document.getElementById('scatterContainer');
const $grid = document.getElementById('scatterGrid');
const $xLabel = document.getElementById('scatterXLabel');
const $yLabel = document.getElementById('scatterYLabel');
const $tooltip = document.getElementById('tooltip');
const $overlay = document.getElementById('viewportOverlay');
const $badge = document.getElementById('viewportBadge');
const $badgeSw = document.getElementById('badgeSwatch');
const $badgeName = document.getElementById('badgeName');
const $detailCon = document.getElementById('detailsContent');
const $detailEmp = document.getElementById('detailsEmpty');
const $detName = document.getElementById('detailsName');
const $detId = document.getElementById('detailsId');
const $detDesc = document.getElementById('detailsDesc');
const $propBars = document.getElementById('propBars');

function scoreToPercent(val) {
  return PADDING.left + ((val - 1) / 9) * (100 - PADDING.left - PADDING.right);
}

export function createGrid() {
  $grid.innerHTML = '';
  for (let i = 1; i <= 10; i++) {
    const pct = scoreToPercent(i);
    const vLine = document.createElement('div');
    vLine.className = 'grid-line grid-line-v';
    vLine.style.left = pct + '%';
    $grid.appendChild(vLine);
    const hLine = document.createElement('div');
    hLine.className = 'grid-line grid-line-h';
    hLine.style.top = pct + '%';
    $grid.appendChild(hLine);
    const txL = document.createElement('span');
    txL.className = 'tick-label';
    txL.textContent = i;
    txL.style.left = pct + '%';
    txL.style.bottom = '4px';
    txL.style.transform = 'translateX(-50%)';
    $grid.appendChild(txL);
    const txR = document.createElement('span');
    txR.className = 'tick-label';
    txR.textContent = i;
    txR.style.top = (100 - pct) + '%';
    txR.style.left = '4px';
    txR.style.transform = 'translateY(-50%)';
    $grid.appendChild(txR);
  }
}

export function createNodes(onClickFn) {
  flooringData.forEach((mat, i) => {
    const el = document.createElement('div');
    el.className = 'material-node entering';
    el.dataset.id = mat.id;
    el.style.background = mat.color;
    el.textContent = mat.name.charAt(0);
    const label = document.createElement('span');
    label.className = 'node-label';
    label.textContent = mat.name;
    el.appendChild(label);
    el.addEventListener('mouseenter', e => onNodeEnter(e, mat));
    el.addEventListener('mousemove', e => onNodeMove(e));
    el.addEventListener('mouseleave', onNodeLeave);
    el.addEventListener('click', () => onClickFn(mat.id));
    $grid.appendChild(el);
    nodeEls[mat.id] = el;
    setTimeout(() => {
      el.classList.remove('entering');
      el.style.animation = 'node-enter 0.4s cubic-bezier(0.34,1.56,0.64,1) forwards';
    }, 80 + i * 60);
  });
}

export function updatePositions(animate) {
  flooringData.forEach(mat => {
    const el = nodeEls[mat.id];
    if (!animate) el.style.transition = 'none';
    el.style.left = scoreToPercent(mat[state.xAxis]) + '%';
    el.style.top  = (100 - scoreToPercent(mat[state.yAxis])) + '%';
    if (!animate) requestAnimationFrame(() => { el.style.transition = ''; });
  });
}

export function updateAxisLabels() {
  $xLabel.textContent = AXIS_META[state.xAxis].label + ' →';
  $yLabel.textContent = AXIS_META[state.yAxis].label + ' →';
}

/* ─── Tooltip ─── */
function onNodeEnter(e, mat) {
  const vals = ['roughness','durability','warmth','maintenance'];
  let html = '<div class="tooltip-name">' + mat.name + '</div>';
  vals.forEach(v => {
    html += '<div class="tooltip-row"><span class="tooltip-label">' + AXIS_META[v].shortLabel +
            '</span><span class="tooltip-value">' + mat[v] + '/10</span></div>';
  });
  $tooltip.innerHTML = html;
  $tooltip.classList.add('visible');
  positionTooltip(e);
}
function onNodeMove(e) { positionTooltip(e); }
function onNodeLeave() { $tooltip.classList.remove('visible'); }
function positionTooltip(e) {
  let x = e.clientX + 16, y = e.clientY - 10;
  const r = $tooltip.getBoundingClientRect();
  if (x + r.width > window.innerWidth - 8) x = e.clientX - r.width - 16;
  if (y + r.height > window.innerHeight - 8) y = window.innerHeight - r.height - 8;
  if (y < 8) y = 8;
  $tooltip.style.left = x + 'px';
  $tooltip.style.top  = y + 'px';
}

/* ─── Material Details ─── */
export function showMaterialDetails(mat) {
  $overlay.classList.add('hidden');
  $badge.classList.remove('hidden');
  $badgeSw.style.background = mat.color;
  $badgeName.textContent = mat.name;
  $detailEmp.classList.add('hidden');
  $detailCon.classList.remove('hidden');
  $detName.textContent = mat.name;
  $detId.textContent = mat.id;
  $detDesc.textContent = mat.description;
  $propBars.innerHTML = '';
  const propColors = {
    roughness: '#b85c38', durability: '#5c7a8a',
    warmth: '#c4a860', maintenance: '#8b6b5a'
  };
  ['roughness','durability','warmth','maintenance'].forEach(key => {
    const val = mat[key];
    const row = document.createElement('div');
    row.className = 'prop-bar';
    row.innerHTML =
      '<span class="prop-label">' + AXIS_META[key].shortLabel + '</span>' +
      '<div class="prop-track"><div class="prop-fill" style="width:0%;background:' + propColors[key] + '"></div></div>' +
      '<span class="prop-value">' + val + '/10</span>';
    $propBars.appendChild(row);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        row.querySelector('.prop-fill').style.width = (val * 10) + '%';
      });
    });
  });
}

export function showEmptyState() {
  $overlay.classList.remove('hidden');
  $badge.classList.add('hidden');
  $detailEmp.classList.remove('hidden');
  $detailCon.classList.add('hidden');
}
